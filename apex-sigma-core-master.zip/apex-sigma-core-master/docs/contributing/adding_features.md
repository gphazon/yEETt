# Adding a new feature

1. Fork the repository.
1. Create a feature branch in your repository and base it on the current `master` branch.
1. Commit your changes and push them to the feature branch of your repo.
1. Open a pull request from your feature branch.

We will respond to your PR as soon as possible.
